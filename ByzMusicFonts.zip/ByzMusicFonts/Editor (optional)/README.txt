The EZ Psaltica Editor is a handy tool for inserting characters of the "EZ Psaltica" font package into a Word document without using the keyboard.
This editor will only work after the font package has been installed. (It is available free at http://www.stanthonysmonastery.org/music/ByzMusicFonts.html )
Simply click on the neume you want, and it will instantly be inserted into your current Word document.
Warning: If you remove the "EZ Psaltica Editor" application from its folder, it will not work unless you also copy all the other files in its folder to its new location.
If you encounter any difficulties, do not hesitate to contact me at: byzmusic@yahoo.com
+Fr. Ephraim

A word to the wise: If you think you will be writing many pages of Byzantine music, I urge you to learn how to type the neumes with the keyboard rather than 
relying on this Editor, because once your fingers know where the common neumes are, you will be able to write music much faster by typing them. This is due 
to the fact that actions done with the keyboard are inherently faster than actions done with the mouse.
